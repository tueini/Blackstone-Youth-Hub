// public/js/config.js
// TO DO: Replace these placeholders with your actual Google Cloud credentials.
// Keep this file out of public version control (e.g., add to .gitignore).

export const GOOGLE_API_KEY = "AIzaSyATp1zqQ8E6HzLMqHJKZ-ooIzuVEn7Me_o";
export const GOOGLE_CLIENT_ID = "956450429708-116fpbs1e1d3j2qvvg91se6crt0dd0ds.apps.googleusercontent.com";
export const GOOGLE_APP_ID = "blackstone-ward-youth-hub";
